import { createContext, useContext, useState } from "react";

const CarritoContext = createContext();

export const useCarrito = () => useContext(CarritoContext);

export const CarritoProvider = ({ children }) => {
  const [carrito, setCarrito] = useState([]);

  const agregar = (producto, cantidad = 1) => {
    setCarrito((prev) => {
      const existente = prev.find((p) => p.id === producto.id);
      if (existente) {
        return prev.map((p) =>
          p.id === producto.id ? { ...p, cantidad: p.cantidad + cantidad } : p
        );
      }
      return [...prev, { ...producto, cantidad }];
    });
  };

  const actualizarCantidad = (id, nuevaCantidad) => {
    if (nuevaCantidad < 1) {
      quitar(id);
    } else {
      setCarrito((prev) =>
        prev.map((p) =>
          p.id === id ? { ...p, cantidad: nuevaCantidad } : p
        )
      );
    }
  };

  const quitar = (id) => {
    setCarrito((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <CarritoContext.Provider value={{ carrito, agregar, quitar, actualizarCantidad }}>
      {children}
    </CarritoContext.Provider>
  );
};

