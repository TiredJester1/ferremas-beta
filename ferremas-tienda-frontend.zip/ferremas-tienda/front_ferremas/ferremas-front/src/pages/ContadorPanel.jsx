import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';

const ContadorPanel = () => {
  // Como no usas setVentas, solo declaramos ventas
  const [ventas] = useState([
    { id: 1, cliente: 'Juan Pérez', producto: 'Taladro Makita', total: 89990, fecha: '2025-06-01' },
    { id: 2, cliente: 'Ana Díaz', producto: 'Caja herramientas', total: 49990, fecha: '2025-06-02' },
    { id: 3, cliente: 'Luis Gómez', producto: 'Martillo Stanley', total: 9990, fecha: '2025-06-03' },
  ]);

  const [busqueda, setBusqueda] = useState('');
  const [fechaInicio, setFechaInicio] = useState('');
  const [fechaFin, setFechaFin] = useState('');
  const [totalVentas, setTotalVentas] = useState(0);
  const [resumen, setResumen] = useState({});

  // Filtrar ventas según búsqueda y rango de fechas
  const ventasFiltradas = ventas.filter((v) => {
    const texto = `${v.cliente} ${v.producto}`.toLowerCase();
    const coincideBusqueda = texto.includes(busqueda.toLowerCase());
    const fechaVenta = new Date(v.fecha);
    const dentroRango =
      (!fechaInicio || fechaVenta >= new Date(fechaInicio)) &&
      (!fechaFin || fechaVenta <= new Date(fechaFin));
    return coincideBusqueda && dentroRango;
  });

  // Recalcular totales y resumen cuando cambian ventas filtradas
  useEffect(() => {
    const total = ventasFiltradas.reduce((acc, curr) => acc + curr.total, 0);
    setTotalVentas(total);

    if (ventasFiltradas.length > 0) {
      const promedio = Math.round(total / ventasFiltradas.length);
      const clienteTop = ventasFiltradas.reduce((max, curr) =>
        curr.total > max.total ? curr : max
      );
      setResumen({
        cantidad: ventasFiltradas.length,
        promedio,
        clienteMayorCompra: clienteTop.cliente,
      });
    } else {
      setResumen({});
    }
  }, [ventasFiltradas]);

  // Exportar CSV
  const exportarCSV = () => {
    const encabezado = 'Cliente,Producto,Fecha,Total\n';
    const filas = ventasFiltradas
      .map((v) => `${v.cliente},${v.producto},${v.fecha},${v.total}`)
      .join('\n');
    const blob = new Blob([encabezado + filas], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'ventas.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 p-6">
      <Navbar />
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">Panel de Contador</h1>

        {/* Filtros */}
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <input
            type="text"
            placeholder="Buscar cliente o producto..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="px-4 py-2 rounded border border-gray-300 shadow-sm bg-white"
          />
          <input
            type="date"
            value={fechaInicio}
            onChange={(e) => setFechaInicio(e.target.value)}
            className="px-4 py-2 rounded border border-gray-300 bg-white"
          />
          <input
            type="date"
            value={fechaFin}
            onChange={(e) => setFechaFin(e.target.value)}
            className="px-4 py-2 rounded border border-gray-300 bg-white"
          />
        </div>

        {/* Tabla de ventas */}
        <div className="overflow-x-auto shadow-md rounded mb-6">
          <table className="min-w-full bg-white rounded">
            <thead>
              <tr className="bg-gray-200 text-left text-gray-700">
                <th className="py-3 px-4">Cliente</th>
                <th className="py-3 px-4">Producto</th>
                <th className="py-3 px-4">Fecha</th>
                <th className="py-3 px-4">Total</th>
              </tr>
            </thead>
            <tbody>
              {ventasFiltradas.length > 0 ? (
                ventasFiltradas.map((v) => (
                  <tr key={v.id} className="border-t border-gray-300">
                    <td className="py-3 px-4">{v.cliente}</td>
                    <td className="py-3 px-4">{v.producto}</td>
                    <td className="py-3 px-4">{v.fecha}</td>
                    <td className="py-3 px-4">${v.total.toLocaleString('es-CL')}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="text-center py-6 text-gray-500">
                    No se encontraron resultados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Resumen */}
        <div className="grid md:grid-cols-2 gap-4 items-center mb-6">
          <div>
            <p className="text-lg font-semibold">
              Total acumulado:{' '}
              <span className="text-green-600">
                ${totalVentas.toLocaleString('es-CL')}
              </span>
            </p>
            {resumen.cantidad && (
              <div className="text-sm text-gray-700 mt-2 space-y-1">
                <p>N° de ventas: {resumen.cantidad}</p>
                <p>Promedio por venta: ${resumen.promedio.toLocaleString('es-CL')}</p>
                <p>Mayor compra: {resumen.clienteMayorCompra}</p>
              </div>
            )}
          </div>

          <div className="flex justify-end">
            <button
              onClick={exportarCSV}
              className="bg-yellow-400 text-black font-semibold px-6 py-2 rounded hover:bg-yellow-300 shadow"
            >
              Exportar CSV
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContadorPanel;
