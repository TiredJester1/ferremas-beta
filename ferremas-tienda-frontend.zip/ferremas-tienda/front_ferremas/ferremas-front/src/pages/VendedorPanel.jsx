import React, { useState } from 'react';
import Navbar from '../components/Navbar';

const VendedorPanel = () => {
  // Simulación de pedidos
  const [pedidos, setPedidos] = useState([
    { id: 1, cliente: 'Juan Pérez', producto: 'Taladro Makita', cantidad: 2, estado: 'Pendiente', fecha: '2025-06-20' },
    { id: 2, cliente: 'María López', producto: 'Martillo Stanley', cantidad: 1, estado: 'Enviado', fecha: '2025-06-18' },
    { id: 3, cliente: 'Carlos Ruiz', producto: 'Caja de herramientas', cantidad: 3, estado: 'Entregado', fecha: '2025-06-15' },
  ]);

  // Control edición estado pedido
  const [editandoId, setEditandoId] = useState(null);
  const [estadoEditado, setEstadoEditado] = useState('');

  // Paginación y búsqueda
  const [busqueda, setBusqueda] = useState('');
  const [paginaActual, setPaginaActual] = useState(1);
  const itemsPorPagina = 5;

  const pedidosFiltrados = pedidos.filter(p =>
    p.cliente.toLowerCase().includes(busqueda.toLowerCase()) ||
    p.producto.toLowerCase().includes(busqueda.toLowerCase()) ||
    p.estado.toLowerCase().includes(busqueda.toLowerCase())
  );

  const totalPaginas = Math.ceil(pedidosFiltrados.length / itemsPorPagina);

  const pedidosMostrados = pedidosFiltrados.slice(
    (paginaActual - 1) * itemsPorPagina,
    paginaActual * itemsPorPagina
  );

  const iniciarEdicion = (pedido) => {
    setEditandoId(pedido.id);
    setEstadoEditado(pedido.estado);
  };

  const guardarEdicion = (id) => {
    setPedidos(
      pedidos.map((p) => (p.id === id ? { ...p, estado: estadoEditado } : p))
    );
    setEditandoId(null);
    setEstadoEditado('');
  };

  const cancelarEdicion = () => {
    setEditandoId(null);
    setEstadoEditado('');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6 transition-colors duration-500">
      <Navbar />
      <div className="max-w-6xl mx-auto">

        <h1 className="text-4xl font-bold text-center text-gray-800 mb-10">
          Panel de Vendedor
        </h1>

        {/* Buscador */}
        <div className="mb-6 max-w-md mx-auto">
          <input
            type="text"
            placeholder="Buscar pedidos..."
            value={busqueda}
            onChange={(e) => {
              setBusqueda(e.target.value);
              setPaginaActual(1);
            }}
            className="w-full border border-gray-400 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-gray-900"
            aria-label="Buscar pedidos"
          />
        </div>

        {/* Tabla de pedidos */}
        <section>
          <h2 className="text-2xl font-semibold mb-4 text-gray-700">
            Pedidos
          </h2>
          <div className="overflow-x-auto rounded shadow-md">
            <table className="min-w-full bg-white">
              <thead>
                <tr className="bg-gray-200 text-gray-700">
                  <th className="py-3 px-4 text-left">Cliente</th>
                  <th className="py-3 px-4 text-left">Producto</th>
                  <th className="py-3 px-4 text-left">Cantidad</th>
                  <th className="py-3 px-4 text-left">Estado</th>
                  <th className="py-3 px-4 text-left">Fecha</th>
                  <th className="py-3 px-4 text-left">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {pedidosMostrados.length === 0 && (
                  <tr>
                    <td colSpan="6" className="text-center py-6 text-gray-500">
                      No se encontraron pedidos.
                    </td>
                  </tr>
                )}
                {pedidosMostrados.map((pedido) => (
                  <tr key={pedido.id} className="border-t border-gray-300">
                    <td className="py-3 px-4 text-gray-900">{pedido.cliente}</td>
                    <td className="py-3 px-4 text-gray-900">{pedido.producto}</td>
                    <td className="py-3 px-4 text-gray-900">{pedido.cantidad}</td>
                    <td className="py-3 px-4 text-gray-900">
                      {editandoId === pedido.id ? (
                        <select
                          value={estadoEditado}
                          onChange={(e) => setEstadoEditado(e.target.value)}
                          className="border rounded px-3 py-1 text-gray-900 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                          aria-label={`Editar estado pedido de ${pedido.cliente}`}
                        >
                          <option value="Pendiente">Pendiente</option>
                          <option value="Enviado">Enviado</option>
                          <option value="Entregado">Entregado</option>
                          <option value="Cancelado">Cancelado</option>
                        </select>
                      ) : (
                        pedido.estado
                      )}
                    </td>
                    <td className="py-3 px-4 text-gray-900">{pedido.fecha}</td>
                    <td className="py-3 px-4 space-x-2">
                      {editandoId === pedido.id ? (
                        <>
                          <button
                            onClick={() => guardarEdicion(pedido.id)}
                            className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 focus:outline-none"
                            aria-label={`Guardar estado pedido de ${pedido.cliente}`}
                          >
                            Guardar
                          </button>
                          <button
                            onClick={cancelarEdicion}
                            className="bg-gray-400 text-white px-3 py-1 rounded hover:bg-gray-500 focus:outline-none"
                            aria-label={`Cancelar edición estado pedido de ${pedido.cliente}`}
                          >
                            Cancelar
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => iniciarEdicion(pedido)}
                          className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600 focus:outline-none"
                          aria-label={`Editar estado pedido de ${pedido.cliente}`}
                        >
                          Editar
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Paginación */}
          {totalPaginas > 1 && (
            <nav
              aria-label="Paginación pedidos"
              className="flex justify-center mt-6 space-x-2 select-none"
            >
              <button
                onClick={() => setPaginaActual((p) => Math.max(p - 1, 1))}
                disabled={paginaActual === 1}
                className="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400 disabled:opacity-50 focus:outline-none"
                aria-label="Página anterior"
              >
                ‹
              </button>
              {[...Array(totalPaginas).keys()].map((i) => (
                <button
                  key={i}
                  onClick={() => setPaginaActual(i + 1)}
                  aria-current={paginaActual === i + 1 ? 'page' : undefined}
                  className={`px-3 py-1 rounded focus:outline-none ${
                    paginaActual === i + 1
                      ? 'bg-yellow-400 font-semibold'
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
              <button
                onClick={() => setPaginaActual((p) => Math.min(p + 1, totalPaginas))}
                disabled={paginaActual === totalPaginas}
                className="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400 disabled:opacity-50 focus:outline-none"
                aria-label="Página siguiente"
              >
                ›
              </button>
            </nav>
          )}
        </section>
      </div>
    </div>
  );
};

export default VendedorPanel;
