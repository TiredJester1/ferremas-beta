import React from 'react';
import { useCarrito } from '../context/CarritoContext';
import { Link } from 'react-router-dom';    
import taladroImg from '../assets/taladro_bosch.jpg';
import martilloImg from '../assets/martillo_stanley.png';
import pinturaImg from '../assets/pintura_sika.webp';

const productos = [
  { id: 1, nombre: "Taladro Bosch", precio: 85000, imagen: taladroImg },
  { id: 2, nombre: "Martillo Stanley", precio: 12000, imagen: martilloImg },
  { id: 3, nombre: "Pintura Sika", precio: 23000, imagen: pinturaImg },
];

export default function Catalogo() {
  const { carrito, agregar, quitar, actualizarCantidad } = useCarrito();

  const getCantidad = (id) => carrito.find(p => p.id === id)?.cantidad || 0;

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      {/* Botón para volver al Home */}
      <Link
        to="/"
        className="inline-block mb-6 text-blue-600 hover:underline hover:text-blue-800"
      >
        ← Volver al inicio
      </Link>

      <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">Catálogo de Productos</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {productos.map((prod) => {
          const cantidad = getCantidad(prod.id);

          return (
            <div key={prod.id} className="bg-white rounded-lg shadow-md p-4 flex flex-col items-center transition hover:shadow-xl">
              <img src={prod.imagen} alt={prod.nombre} className="w-40 h-40 object-cover mb-4" />
              <h2 className="font-semibold text-lg mb-2">{prod.nombre}</h2>
              <p className="text-gray-700 mb-4">${prod.precio.toLocaleString("es-CL")}</p>

              {cantidad > 0 ? (
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => actualizarCantidad(prod.id, cantidad - 1)}
                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="0"
                    value={cantidad}
                    onChange={(e) =>
                      actualizarCantidad(prod.id, Math.max(0, parseInt(e.target.value) || 0))
                    }
                    className="w-12 text-center border rounded"
                  />
                  <button
                    onClick={() => agregar(prod, 1)}
                    className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600"
                  >
                    +
                  </button>
                  <button
                    onClick={() => quitar(prod.id)}
                    className="ml-2 text-sm text-red-500 underline hover:text-red-700"
                  >
                    Quitar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => agregar(prod, 1)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
                >
                  Agregar al carrito
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}



