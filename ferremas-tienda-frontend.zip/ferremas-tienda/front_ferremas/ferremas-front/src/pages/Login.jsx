import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Navbar from '../components/Navbar';

const Login = () => {
  const navigate = useNavigate();
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [perfil, setPerfil] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();

    if (!correo || !password || !perfil) {
      setError('Completa todos los campos.');
      return;
    }

    const usuario = {
      correo,
      perfil,
    };

    localStorage.setItem('usuario', JSON.stringify(usuario));
    setError('');

    switch (perfil) {
      case 'administrador':
        navigate('/admin');
        break;
      case 'vendedor':
        navigate('/vendedor');
        break;
      case 'bodeguero':
        navigate('/bodeguero');
        break;
      case 'contador':
        navigate('/contador');
        break;
      case 'cliente':
        navigate('/');
        break;
      default:
        navigate('/');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 via-blue-200 to-blue-300 px-4">
      <Navbar />
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg max-w-md w-full p-8 transition-colors duration-500">
        <h2 className="text-3xl font-bold mb-6 text-center text-blue-800 dark:text-blue-300">
          Iniciar Sesión
        </h2>

        {error && (
          <div className="mb-4 text-red-700 bg-red-100 dark:bg-red-200 dark:text-red-800 p-3 rounded">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label htmlFor="correo" className="block mb-1 font-semibold text-blue-700 dark:text-blue-300">
              Correo Electrónico
            </label>
            <input
              id="correo"
              type="email"
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
              className="w-full px-4 py-3 border border-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 dark:bg-gray-800 dark:border-blue-600 dark:text-blue-100"
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="block mb-1 font-semibold text-blue-700 dark:text-blue-300">
              Contraseña
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 dark:bg-gray-800 dark:border-blue-600 dark:text-blue-100"
              required
            />
          </div>

          <div>
            <label htmlFor="perfil" className="block mb-1 font-semibold text-blue-700 dark:text-blue-300">
              Perfil
            </label>
            <select
              id="perfil"
              value={perfil}
              onChange={(e) => setPerfil(e.target.value)}
              className="w-full px-4 py-3 border border-blue-300 rounded-md bg-white dark:bg-gray-800 dark:border-blue-600 dark:text-blue-100"
              required
            >
              <option value="">-- Seleccionar --</option>
              <option value="cliente">Cliente</option>
              <option value="administrador">Administrador</option>
              <option value="vendedor">Vendedor</option>
              <option value="bodeguero">Bodeguero</option>
              <option value="contador">Contador</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md shadow-md focus:outline-none focus:ring-4 focus:ring-blue-300"
          >
            Iniciar Sesión
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-blue-700 dark:text-blue-300">
            ¿No tienes cuenta?{' '}
            <Link
              to="/registro"
              className="text-blue-800 hover:text-blue-900 font-semibold dark:text-blue-200 dark:hover:text-white"
            >
              Regístrate
            </Link>
          </p>
          <Link
            to="/"
            className="mt-3 inline-block text-blue-600 hover:text-blue-800 font-semibold dark:text-blue-300 dark:hover:text-blue-100"
          >
            ← Volver a inicio
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
