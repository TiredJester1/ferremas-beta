import React, { useState } from 'react';
import { useCarrito } from '../context/CarritoContext';
import { ShoppingCart } from 'lucide-react'; 
import { Link } from 'react-router-dom'; 

export default function CarritoFlotante() {
  const { carrito, quitar } = useCarrito();
  const [abierto, setAbierto] = useState(false);

  return (
    <div className="fixed top-6 right-6 z-50">
      <button
        onClick={() => setAbierto(!abierto)}
        className="relative bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full shadow-lg transition"
        aria-label="Toggle carrito"
      >
        <ShoppingCart className="w-6 h-6" />
        {carrito.length > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 rounded-full text-xs px-2 font-bold">
            {carrito.length}
          </span>
        )}
      </button>

      {abierto && (
        <div className="mt-2 w-80 bg-white shadow-xl rounded-lg p-4 max-h-96 overflow-y-auto">
          <h3 className="text-lg font-semibold mb-2">Carrito</h3>
          {carrito.length === 0 ? (
            <p className="text-gray-500 text-sm">No hay productos aún.</p>
          ) : (
            <>
              <ul className="space-y-3 mb-4">
                {carrito.map((item) => (
                  <li key={item.id} className="flex justify-between items-center border-b pb-2">
                    <div>
                      <p className="font-medium">{item.nombre}</p>
                      <p className="text-sm text-gray-600">${item.precio.toLocaleString("es-CL")}</p>
                    </div>
                    <button
                      onClick={() => quitar(item.id)}
                      className="text-red-600 hover:text-red-800 text-sm"
                    >
                      Quitar
                    </button>
                  </li>
                ))}
              </ul>

              <Link
                to="/pago"
                className="block text-center bg-green-600 hover:bg-green-700 text-white py-2 rounded transition"
                onClick={() => setAbierto(false)} // Cierra el carrito al ir a pagar
              >
                Ir a pagar
              </Link>
            </>
          )}
        </div>
      )}
    </div>
  );
}

