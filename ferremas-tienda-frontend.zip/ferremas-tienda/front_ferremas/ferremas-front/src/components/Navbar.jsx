import React from "react";
import { Link, useLocation } from "react-router-dom";

const Navbar = () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  const location = useLocation();

  // Ocultar navbar en login
  if (location.pathname === "/login") {
    return null;
  }

  const cerrarSesion = () => {
    localStorage.removeItem("usuario");
    window.location.reload();
  };

  return (
    <nav className="bg-gray-800 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-wrap justify-between items-center">
        {/* Logo y sesión */}
        <div className="flex items-center space-x-6 min-w-0">
          <h2 className="text-2xl font-bold text-yellow-400 flex-shrink-0">FERREMAS</h2>

          {usuario && (
            <div className="text-sm bg-gray-700 px-3 py-1 rounded flex items-center space-x-2 max-w-xs truncate">
              <span className="truncate">
                Sesión: <strong>{usuario.correo}</strong> ({usuario.perfil})
              </span>
              <button
                onClick={cerrarSesion}
                className="text-yellow-300 hover:underline flex-shrink-0"
                title="Cerrar sesión"
              >
                Cerrar sesión
              </button>
            </div>
          )}
        </div>

        {/* Menú */}
        <div className="flex items-center space-x-4 text-sm overflow-x-auto min-w-0">
          <Link to="/" className="hover:text-yellow-400 whitespace-nowrap">
            Inicio
          </Link>

          {usuario?.perfil === "cliente" && location.pathname !== "/mi-cuenta" && (
            <Link to="/mi-cuenta" className="hover:text-yellow-400 whitespace-nowrap">
              Mi cuenta
            </Link>
          )}

          <Link to="/catalogo" className="hover:text-yellow-400 whitespace-nowrap">
            Catálogo
          </Link>

          {usuario?.perfil === "bodeguero" && (
            <Link to="/bodeguero" className="hover:text-yellow-400 whitespace-nowrap">
              Inventario
            </Link>
          )}
          {usuario?.perfil === "administrador" && (
            <Link to="/admin" className="hover:text-yellow-400 whitespace-nowrap">
              Administrar
            </Link>
          )}
          {usuario?.perfil === "vendedor" && (
            <Link to="/vendedor" className="hover:text-yellow-400 whitespace-nowrap">
              Ventas
            </Link>
          )}
          {usuario?.perfil === "contador" && (
            <Link to="/contador" className="hover:text-yellow-400 whitespace-nowrap">
              Contabilidad
            </Link>
          )}

          {!usuario && (
            <>
              <Link to="/login" className="hover:text-yellow-400 whitespace-nowrap">
                Iniciar sesión
              </Link>
              <Link
                to="/registro"
                className="bg-yellow-400 hover:bg-yellow-300 text-black font-semibold px-3 py-1 rounded shadow text-sm whitespace-nowrap"
              >
                Registrarse
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
