import React from "react";
import { Link, useLocation } from "react-router-dom";

const Navbar = () => {
  const usuario = JSON.parse(localStorage.getItem('usuario'));
  const location = useLocation();

  const cerrarSesion = () => {
    localStorage.removeItem('usuario');
    window.location.reload();
  };

  return (
    <nav className="bg-gray-800 text-white px-6 py-4 flex justify-between items-center">
      <div className="flex items-center space-x-4">
        <h2 className="text-xl font-semibold">FERREMAS</h2>

        {usuario && (
          <div className="bg-gray-700 px-3 py-1 rounded flex items-center space-x-3 text-sm">
            <span>
              Sesión: <strong>{usuario.correo}</strong> ({usuario.perfil})
            </span>
            <button
              onClick={cerrarSesion}
              className="text-yellow-400 hover:underline"
              title="Cerrar sesión"
            >
              Cerrar sesión
            </button>
          </div>
        )}
      </div>

      <div className="space-x-4 flex items-center">
        <Link to="/" className="hover:text-yellow-400">
          Inicio
        </Link>

        {/* Mostrar "Mi cuenta" solo para clientes y si no estamos en /mi-cuenta */}
        {usuario?.perfil === "cliente" && location.pathname !== "/mi-cuenta" && (
          <Link to="/mi-cuenta" className="hover:text-yellow-400">
            Mi cuenta
          </Link>
        )}

        <Link to="/catalogo" className="hover:text-yellow-400">
          Catálogo
        </Link>

        {/* Botón para perfil bodeguero */}
        {usuario?.perfil === "bodeguero" && (
          <Link to="/bodeguero" className="hover:text-yellow-400">
            Inventario
          </Link>
        )}

        {/* Botón para perfil administrador */}
        {usuario?.perfil === "administrador" && (
          <Link to="/admin" className="hover:text-yellow-400">
            Administrar
          </Link>
        )}

        {/* Botón para perfil vendedor */}
        {usuario?.perfil === "vendedor" && (
          <Link to="/vendedor" className="hover:text-yellow-400">
            Ventas
          </Link>
        )}

        {/* Botón para perfil contador */}
        {usuario?.perfil === "contador" && (
          <Link to="/contador" className="hover:text-yellow-400">
            Contabilidad
          </Link>
        )}

        {/* Botones visibles solo si no hay sesión */}
        {!usuario && (
          <>
            <Link to="/login" className="hover:text-yellow-400">
              Iniciar sesión
            </Link>
            <Link
              to="/registro"
              className="bg-yellow-400 hover:bg-yellow-300 text-black font-semibold px-3 py-1 rounded shadow-md text-sm"
            >
              Registrarse
            </Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
