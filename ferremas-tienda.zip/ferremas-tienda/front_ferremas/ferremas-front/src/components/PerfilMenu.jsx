// src/components/PerfilMenu.jsx
import React, { useState } from 'react';
import { User } from 'lucide-react';

export default function PerfilMenu() {
  const usuario = JSON.parse(localStorage.getItem('usuario'));
  const [abierto, setAbierto] = useState(false);

  const cerrarSesion = () => {
    localStorage.removeItem('usuario');
    window.location.href = '/';
  };

  if (!usuario) return null;

  return (
    <div className="absolute top-4 right-4">
      <div className="relative">
        <button
          onClick={() => setAbierto(!abierto)}
          className="flex items-center space-x-2 text-white hover:text-yellow-300"
        >
          <User className="w-6 h-6" />
          <span className="hidden sm:inline">{usuario.perfil}</span>
        </button>

        {abierto && (
          <div className="absolute right-0 mt-2 w-48 bg-white text-black rounded shadow-md z-50">
            <div className="px-4 py-2 border-b">
              <p className="text-sm font-medium">{usuario.correo}</p>
              <p className="text-xs text-gray-500 capitalize">{usuario.perfil}</p>
            </div>
            <button
              onClick={cerrarSesion}
              className="w-full text-left px-4 py-2 hover:bg-red-100 text-red-600"
            >
              Cerrar sesión
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
