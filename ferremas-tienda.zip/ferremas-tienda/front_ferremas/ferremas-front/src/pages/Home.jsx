import React, { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

// 👇 Arreglo de productos simulados
const bestSellers = [
  {
    id: 1,
    name: "Taladro Makita",
    image: "/img/taladro.jpg",
    price: "$89.990",
  },
  {
    id: 2,
    name: "Caja de herramientas",
    image: "/img/caja.jpg",
    price: "$49.990",
  },
  {
    id: 3,
    name: "Martillo Stanley",
    image: "/img/martillo.jpg",
    price: "$9.990",
  },
];

// 👇 Arreglo de comentarios simulados
const testimonials = [
  {
    id: 1,
    name: "Carlos Gómez",
    comment: "Excelente servicio y productos de calidad. Muy recomendados.",
    photo: "/img/client1.jpg",
  },
  {
    id: 2,
    name: "María López",
    comment: "Encontré todo lo que necesitaba para mi proyecto, atención impecable.",
    photo: "/img/client2.jpg",
  },
  {
    id: 3,
    name: "Juan Pérez",
    comment: "Muy buena experiencia de compra, volveré sin duda.",
    photo: "/img/client3.jpg",
  },
];

const Home = () => {
  const [search, setSearch] = useState("");

  const branches = [
    { nombre: "Sucursal Santiago Centro", direccion: "Av. Libertador 1001", ciudad: "Santiago" },
    { nombre: "Sucursal Viña del Mar", direccion: "Calle 8 Norte 456", ciudad: "Viña del Mar" },
    { nombre: "Sucursal Concepción", direccion: "Barros Arana 789", ciudad: "Concepción" },
    { nombre: "Sucursal La Serena", direccion: "Av. del Mar 1234", ciudad: "La Serena" },
    { nombre: "Sucursal Antofagasta", direccion: "Baquedano 222", ciudad: "Antofagasta" },
  ];

  const filteredBranches = branches.filter((b) =>
    b.ciudad.toLowerCase().includes(search.toLowerCase())
  );

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-blue-700 min-h-screen text-white relative">
      <Navbar />

      <div className="flex flex-col items-center justify-center text-center px-4 py-20">
        <h1 className="text-5xl font-bold mb-6 animate-fade-in">
          Bienvenido a <span className="text-yellow-300">FERREMAS</span>
        </h1>
        <p className="text-xl max-w-xl mb-8">
          Tu distribuidora de confianza en herramientas, materiales de construcción y más.
        </p>

        <Link to="/catalogo">
          <button className="bg-yellow-400 hover:bg-yellow-300 text-black font-semibold px-6 py-3 rounded-full transition transform hover:scale-105 shadow-lg">
            Explorar Catálogo
          </button>
        </Link>
      </div>

      {/* 🔥 Sección Lo más vendido */}
      <section className="bg-white text-black py-12 px-4">
        <h2 className="text-3xl font-bold mb-6 text-center">Lo más vendido</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {bestSellers.map((product) => (
            <motion.div
              key={product.id}
              className="bg-white shadow-md rounded-xl overflow-hidden p-4 cursor-pointer transition-transform hover:scale-105"
              whileInView={{ opacity: 1, y: 0 }}
              initial={{ opacity: 0, y: 50 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-40 object-cover mb-4 rounded-md"
              />
              <h3 className="text-lg font-semibold">{product.name}</h3>
              <p className="text-gray-600">{product.price}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 🗺️ Sección Nuestras sucursales */}
      <section className="bg-white text-black py-16 px-6">
        <motion.div
          className="max-w-4xl mx-auto"
          whileInView={{ opacity: 1, y: 0 }}
          initial={{ opacity: 0, y: 50 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-6 text-center">Nuestras sucursales</h2>

          <input
            type="text"
            placeholder="Buscar por ciudad o comuna..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded mb-6"
          />

          <div className="grid sm:grid-cols-2 gap-6 mb-8">
            {filteredBranches.length > 0 ? (
              filteredBranches.map((branch, i) => (
                <div key={i} className="p-4 bg-blue-50 rounded shadow">
                  <h3 className="font-bold">{branch.nombre}</h3>
                  <p>{branch.direccion}</p>
                  <p className="text-sm text-gray-600">{branch.ciudad}</p>
                </div>
              ))
            ) : (
              <p className="text-center col-span-2">No se encontraron sucursales</p>
            )}
          </div>

          <div className="w-full max-w-3xl mx-auto">
            <img
              src="/img/mapa-chile.png"
              alt="Mapa de Chile"
              className="w-full rounded-lg shadow"
            />
          </div>
        </motion.div>
      </section>

      {/* 🗨️ Sección Comentarios de clientes */}
      <section className="bg-gray-100 text-black py-16 px-6">
        <motion.div
          className="max-w-5xl mx-auto"
          whileInView={{ opacity: 1, y: 0 }}
          initial={{ opacity: 0, y: 50 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-10 text-center">Comentarios de nuestros clientes</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map(({ id, name, comment, photo }) => (
              <div key={id} className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-center mb-4">
                  <img
                    src={photo}
                    alt={name}
                    className="w-14 h-14 rounded-full object-cover mr-4"
                  />
                  <h3 className="font-semibold text-lg">{name}</h3>
                </div>
                <p className="text-gray-700 italic">"{comment}"</p>
              </div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* 🧱 Sección Sobre Nosotros */}
      <section className="bg-blue-100 text-black py-16 px-6">
        <motion.div
          className="max-w-4xl mx-auto"
          whileInView={{ opacity: 1, y: 0 }}
          initial={{ opacity: 0, y: 50 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-6 text-center">Sobre Nosotros</h2>
          <p className="text-lg leading-relaxed text-justify mb-8">
            En <strong>FERREMAS</strong>, somos una empresa con más de 10 años de experiencia distribuyendo herramientas, materiales de construcción y artículos de ferretería de alta calidad. Nos enorgullece entregar confianza, buen servicio y un compromiso constante con nuestros clientes en todo Chile.
            <br /><br />
            Trabajamos con marcas reconocidas y nos adaptamos a las necesidades de nuestros clientes, ya sean empresas o particulares. Nuestra misión es ser la ferretería de confianza que siempre está cerca de ti.
          </p>

          {/* Añadimos aquí "Nuestros contactos" */}
          <div className="mt-6">
            <h3 className="text-2xl font-semibold mb-4 text-center">Nuestros contactos</h3>
            <ul className="text-lg space-y-2 max-w-md mx-auto">
              <li><strong>Teléfono:</strong> +56 2 1234 5678</li>
              <li><strong>Email:</strong> contacto@ferremas.cl</li>
              <li><strong>Dirección:</strong> Av. Principal 1234, Santiago, Chile</li>
              <li><strong>Horario de atención:</strong> Lunes a Viernes, 9:00 - 18:00</li>
            </ul>
          </div>
        </motion.div>
      </section>
    </div>
  );
};

export default Home;
