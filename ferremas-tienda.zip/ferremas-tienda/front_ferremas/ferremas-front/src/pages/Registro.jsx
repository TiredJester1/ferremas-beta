import React, { useState } from 'react';

const Registro = ({ onRegister }) => {
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmarPassword, setConfirmarPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!nombre || !email || !password || !confirmarPassword) {
      setError('Por favor, completa todos los campos.');
      return;
    }
    if (password !== confirmarPassword) {
      setError('Las contraseñas no coinciden.');
      return;
    }
    setError('');
    onRegister({ nombre, email, password });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 via-blue-200 to-blue-300 px-4">
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg max-w-md w-full p-8 transition-colors duration-500">
        <h2 className="text-3xl font-bold mb-6 text-center text-blue-800 dark:text-blue-300">
          Crear Cuenta
        </h2>
        {error && (
          <div className="mb-4 text-red-700 bg-red-100 dark:bg-red-200 dark:text-red-800 p-3 rounded">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} noValidate>
          <label
            htmlFor="nombre"
            className="block mb-1 font-semibold text-blue-700 dark:text-blue-300"
          >
            Nombre Completo
          </label>
          <input
            id="nombre"
            type="text"
            placeholder="Tu nombre completo"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            className="w-full mb-4 px-4 py-3 border border-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 dark:bg-gray-800 dark:border-blue-600 dark:text-blue-100 dark:placeholder-blue-300"
            required
            autoComplete="name"
          />

          <label
            htmlFor="email"
            className="block mb-1 font-semibold text-blue-700 dark:text-blue-300"
          >
            Correo Electrónico
          </label>
          <input
            id="email"
            type="email"
            placeholder="tuemail@ejemplo.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full mb-4 px-4 py-3 border border-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 dark:bg-gray-800 dark:border-blue-600 dark:text-blue-100 dark:placeholder-blue-300"
            required
            autoComplete="email"
          />

          <label
            htmlFor="password"
            className="block mb-1 font-semibold text-blue-700 dark:text-blue-300"
          >
            Contraseña
          </label>
          <input
            id="password"
            type="password"
            placeholder="********"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full mb-4 px-4 py-3 border border-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 dark:bg-gray-800 dark:border-blue-600 dark:text-blue-100 dark:placeholder-blue-300"
            required
            autoComplete="new-password"
          />

          <label
            htmlFor="confirmarPassword"
            className="block mb-1 font-semibold text-blue-700 dark:text-blue-300"
          >
            Confirmar Contraseña
          </label>
          <input
            id="confirmarPassword"
            type="password"
            placeholder="********"
            value={confirmarPassword}
            onChange={(e) => setConfirmarPassword(e.target.value)}
            className="w-full mb-6 px-4 py-3 border border-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 dark:bg-gray-800 dark:border-blue-600 dark:text-blue-100 dark:placeholder-blue-300"
            required
            autoComplete="new-password"
          />

          <button
            type="submit"
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 rounded-md shadow-md transition-colors focus:outline-none focus:ring-4 focus:ring-blue-300"
            aria-label="Registrar nueva cuenta"
          >
            Crear Cuenta
          </button>
        </form>

        {/* Botón Volver a la tienda */}
        <button
          type="button"
          onClick={() => window.location.href = '/store'}
          className="mt-4 w-full bg-blue-300 hover:bg-blue-400 text-blue-900 font-semibold py-2 rounded-md shadow-md transition-colors focus:outline-none focus:ring-4 focus:ring-blue-200"
        >
          Volver a la tienda
        </button>

        <p className="mt-6 text-center text-blue-700 dark:text-blue-300">
          ¿Ya tienes cuenta?{' '}
          <a
            href="/login"
            className="text-blue-600 hover:text-blue-800 font-semibold"
          >
            Inicia sesión
          </a>
        </p>
      </div>
    </div>
  );
};

export default Registro;
