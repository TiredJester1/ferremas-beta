import React, { useState } from 'react';
import Navbar from '../components/Navbar';

const BodegueroPanel = () => {
  const [productos, setProductos] = useState([
    { id: 1, nombre: 'Taladro Makita', stock: 20 },
    { id: 2, nombre: 'Caja de herramientas', stock: 35 },
    { id: 3, nombre: 'Martillo Stanley', stock: 50 },
  ]);

  const [nuevoProducto, setNuevoProducto] = useState({ nombre: '', stock: '' });
  const [editandoId, setEditandoId] = useState(null);
  const [productoEditado, setProductoEditado] = useState({ nombre: '', stock: '' });

  const agregarProducto = (e) => {
    e.preventDefault();
    if (!nuevoProducto.nombre || !nuevoProducto.stock) return alert('Completa todos los campos');
    const nuevo = {
      id: Date.now(),
      nombre: nuevoProducto.nombre,
      stock: parseInt(nuevoProducto.stock),
    };
    setProductos([...productos, nuevo]);
    setNuevoProducto({ nombre: '', stock: '' });
  };

  const iniciarEdicion = (producto) => {
    setEditandoId(producto.id);
    setProductoEditado({ nombre: producto.nombre, stock: producto.stock });
  };

  const guardarEdicion = (id) => {
    setProductos(
      productos.map((p) =>
        p.id === id ? { ...p, nombre: productoEditado.nombre, stock: parseInt(productoEditado.stock) } : p
      )
    );
    setEditandoId(null);
    setProductoEditado({ nombre: '', stock: '' });
  };

  const cancelarEdicion = () => {
    setEditandoId(null);
    setProductoEditado({ nombre: '', stock: '' });
  };

  const eliminarProducto = (id) => {
    if (window.confirm('¿Seguro que quieres eliminar este producto?')) {
      setProductos(productos.filter((p) => p.id !== id));
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <main className="max-w-6xl mx-auto p-6">
        <h1 className="text-4xl font-bold text-center text-gray-800 mb-10">Panel de Bodeguero</h1>

        {/* Agregar nuevo producto */}
        <section className="mb-12 bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-semibold text-gray-700 mb-4">Agregar nuevo producto</h2>
          <form onSubmit={agregarProducto} className="flex flex-col md:flex-row md:items-center gap-4">
            <input
              type="text"
              placeholder="Nombre del producto"
              value={nuevoProducto.nombre}
              onChange={(e) => setNuevoProducto({ ...nuevoProducto, nombre: e.target.value })}
              className="border border-gray-300 p-3 rounded w-full md:w-1/2 shadow-sm"
            />
            <input
              type="number"
              placeholder="Stock"
              value={nuevoProducto.stock}
              onChange={(e) => setNuevoProducto({ ...nuevoProducto, stock: e.target.value })}
              className="border border-gray-300 p-3 rounded w-full md:w-1/4 shadow-sm"
            />
            <button
              type="submit"
              className="bg-green-600 text-white px-6 py-3 rounded hover:bg-green-700 transition font-semibold shadow"
            >
              Agregar
            </button>
          </form>
        </section>

        {/* Tabla de inventario */}
        <section className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-semibold text-gray-700 mb-4">Inventario actual</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white rounded shadow-md">
              <thead>
                <tr className="bg-gray-200 text-gray-700 text-left">
                  <th className="py-3 px-6">Nombre</th>
                  <th className="py-3 px-6">Stock</th>
                  <th className="py-3 px-6">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {productos.map((producto) => (
                  <tr key={producto.id} className="border-t hover:bg-gray-50">
                    <td className="py-3 px-6">
                      {editandoId === producto.id ? (
                        <input
                          type="text"
                          value={productoEditado.nombre}
                          onChange={(e) => setProductoEditado({ ...productoEditado, nombre: e.target.value })}
                          className="border p-2 rounded w-full"
                        />
                      ) : (
                        producto.nombre
                      )}
                    </td>
                    <td className="py-3 px-6">
                      {editandoId === producto.id ? (
                        <input
                          type="number"
                          value={productoEditado.stock}
                          onChange={(e) => setProductoEditado({ ...productoEditado, stock: e.target.value })}
                          className="border p-2 rounded w-full"
                        />
                      ) : (
                        producto.stock
                      )}
                    </td>
                    <td className="py-3 px-6 space-x-2">
                      {editandoId === producto.id ? (
                        <>
                          <button
                            onClick={() => guardarEdicion(producto.id)}
                            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                          >
                            Guardar
                          </button>
                          <button
                            onClick={cancelarEdicion}
                            className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500 transition"
                          >
                            Cancelar
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => iniciarEdicion(producto)}
                            className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition"
                          >
                            Editar
                          </button>
                          <button
                            onClick={() => eliminarProducto(producto.id)}
                            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition"
                          >
                            Eliminar
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
};

export default BodegueroPanel;
