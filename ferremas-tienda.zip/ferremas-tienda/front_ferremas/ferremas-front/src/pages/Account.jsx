import React, { useState } from "react";
import Navbar from "../components/Navbar";
import { useNavigate } from "react-router-dom";

const Account = () => {
  const navigate = useNavigate();

  const [user, setUser] = useState({
    name: "Juan Pérez",
    email: "juan.perez@email.com",
    address: "Av. Siempre Viva 123, Santiago, Chile",
  });

  const [orders] = useState([
    { id: "1001", date: "2025-06-01", status: "Enviado", total: "$45.000" },
    { id: "1002", date: "2025-05-28", status: "Procesando", total: "$120.000" },
  ]);

  // 👉 Estados para rastreo
  const [trackingId, setTrackingId] = useState("");
  const [trackingResult, setTrackingResult] = useState(null);

  const handleLogout = () => {
    localStorage.removeItem("usuario");
    navigate("/");
  };

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleTrackingSubmit = (e) => {
    e.preventDefault();
    const pedido = orders.find((o) => o.id === trackingId);
    setTrackingResult(pedido || null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-600 via-blue-500 to-blue-700 text-white">
      <Navbar />

      <main className="max-w-4xl mx-auto p-6">
        <h1 className="text-4xl font-bold mb-8 text-center">Mi Cuenta</h1>

        {/* 🧍 Información personal */}
        <section className="bg-white text-black rounded-lg p-6 mb-8 shadow-lg">
          <h2 className="text-2xl font-semibold mb-4">Información personal</h2>
          <form>
            <label className="block mb-2 font-semibold" htmlFor="name">Nombre</label>
            <input
              type="text"
              id="name"
              name="name"
              value={user.name}
              onChange={handleChange}
              className="w-full p-2 mb-4 border border-gray-300 rounded"
            />

            <label className="block mb-2 font-semibold" htmlFor="email">Correo electrónico</label>
            <input
              type="email"
              id="email"
              name="email"
              value={user.email}
              onChange={handleChange}
              className="w-full p-2 mb-4 border border-gray-300 rounded"
            />

            <label className="block mb-2 font-semibold" htmlFor="address">Dirección de envío</label>
            <input
              type="text"
              id="address"
              name="address"
              value={user.address}
              onChange={handleChange}
              className="w-full p-2 mb-4 border border-gray-300 rounded"
            />
          </form>
        </section>

        {/* 📦 Pedidos y rastreo */}
        <section className="bg-white text-black rounded-lg p-6 mb-8 shadow-lg">
          <h2 className="text-2xl font-semibold mb-4">Mis pedidos</h2>

          {/* 🔍 Rastreo de pedidos */}
          <form onSubmit={handleTrackingSubmit} className="mb-6 flex flex-col sm:flex-row gap-4">
            <input
              type="text"
              placeholder="Ingresa el número de pedido para rastrear"
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
              className="w-full sm:w-auto px-4 py-2 border border-gray-300 rounded"
            />
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
            >
              Seguir pedido
            </button>
          </form>

          {/* 🔎 Resultado de rastreo */}
          {trackingResult ? (
            <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-800 rounded">
              Pedido <strong>{trackingResult.id}</strong> está actualmente:{" "}
              <strong>{trackingResult.status}</strong> 📦
            </div>
          ) : trackingId && (
            <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-800 rounded">
              No se encontró ningún pedido con ID <strong>{trackingId}</strong>
            </div>
          )}

          {/* 🧾 Tabla de pedidos */}
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="py-2">ID Pedido</th>
                <th className="py-2">Fecha</th>
                <th className="py-2">Estado</th>
                <th className="py-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id} className="border-b border-gray-200">
                  <td className="py-2">{order.id}</td>
                  <td className="py-2">{order.date}</td>
                  <td className="py-2">{order.status}</td>
                  <td className="py-2">{order.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <button
          onClick={handleLogout}
          className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded transition"
        >
          Cerrar sesión
        </button>
      </main>
    </div>
  );
};

export default Account;
