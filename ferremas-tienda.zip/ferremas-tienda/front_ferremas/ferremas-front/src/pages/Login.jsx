import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';

const Login = () => {
  const navigate = useNavigate();
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [perfil, setPerfil] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();

    if (!correo || !password || !perfil) {
      setError('Completa todos los campos');
      return;
    }

    const usuario = {
      correo,
      perfil,
    };

    localStorage.setItem('usuario', JSON.stringify(usuario));
    setError('');

    // Redirige según el perfil
    switch (perfil) {
      case 'administrador':
        navigate('/admin');
        break;
      case 'vendedor':
        navigate('/vendedor');
        break;
      case 'bodeguero':
        navigate('/bodeguero');
        break;
      case 'contador':
        navigate('/contador');
        break;
      case 'cliente': // Ahora redirige a Home para clientes
        navigate('/');
        break;
      default:
        navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <Navbar />
      <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Iniciar Sesión</h2>
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-gray-700 mb-1">Correo electrónico</label>
            <input
              type="email"
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 mb-1">Contraseña</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 mb-1">Selecciona perfil</label>
            <select
              value={perfil}
              onChange={(e) => setPerfil(e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
              required
            >
              <option value="">-- Seleccionar --</option>
              <option value="cliente">Cliente</option>
              <option value="administrador">Administrador</option>
              <option value="vendedor">Vendedor</option>
              <option value="bodeguero">Bodeguero</option>
              <option value="contador">Contador</option>
            </select>
          </div>
          <button
            type="submit"
            className="bg-yellow-400 hover:bg-yellow-300 text-black font-semibold py-2 px-4 rounded w-full"
          >
            Iniciar Sesión
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
