import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';

const AdminPanel = () => {
  const [productos, setProductos] = useState([
    { id: 1, nombre: 'Taladro Makita', precio: 89990, imagenes: [] },
    { id: 2, nombre: 'Caja de herramientas', precio: 49990, imagenes: [] },
    { id: 3, nombre: 'Martillo Stanley', precio: 9990, imagenes: [] },
  ]);

  const [nuevoProducto, setNuevoProducto] = useState({
    nombre: '',
    precio: '',
    imagenes: [],
  });
  const [editandoId, setEditandoId] = useState(null);
  const [productoEditado, setProductoEditado] = useState({
    nombre: '',
    precio: '',
    imagenes: [],
  });

  const [loading, setLoading] = useState(false);

  const [busqueda, setBusqueda] = useState('');
  const [paginaActual, setPaginaActual] = useState(1);
  const itemsPorPagina = 5;

  const [modalEliminar, setModalEliminar] = useState({ abierto: false, id: null });

  const [undo, setUndo] = useState(null);

  const productosFiltrados = productos.filter(p =>
    p.nombre.toLowerCase().includes(busqueda.toLowerCase())
  );
  const totalPaginas = Math.ceil(productosFiltrados.length / itemsPorPagina);
  const productosMostrados = productosFiltrados.slice(
    (paginaActual - 1) * itemsPorPagina,
    paginaActual * itemsPorPagina
  );

  const agregarProducto = (e) => {
    e.preventDefault();
    if (!nuevoProducto.nombre || !nuevoProducto.precio) {
      alert('Completa todos los campos');
      return;
    }
    setLoading(true);
    const nuevo = {
      id: Date.now(),
      nombre: nuevoProducto.nombre,
      precio: parseFloat(nuevoProducto.precio),
      imagenes: nuevoProducto.imagenes,
    };
    setTimeout(() => {
      setProductos([...productos, nuevo]);
      setNuevoProducto({ nombre: '', precio: '', imagenes: [] });
      setLoading(false);
      setUndo({ accion: 'agregado', producto: nuevo });
    }, 800);
  };

  const iniciarEdicion = (producto) => {
    setEditandoId(producto.id);
    setProductoEditado({
      nombre: producto.nombre,
      precio: producto.precio,
      imagenes: producto.imagenes,
    });
  };

  const guardarEdicion = (id) => {
    if (!productoEditado.nombre || !productoEditado.precio) {
      alert('Completa todos los campos');
      return;
    }
    setLoading(true);
    const antesEditar = productos.find((p) => p.id === id);
    setTimeout(() => {
      setProductos(
        productos.map((p) =>
          p.id === id
            ? {
                ...p,
                nombre: productoEditado.nombre,
                precio: parseFloat(productoEditado.precio),
                imagenes: productoEditado.imagenes,
              }
            : p
        )
      );
      setEditandoId(null);
      setProductoEditado({ nombre: '', precio: '', imagenes: [] });
      setLoading(false);
      setUndo({ accion: 'editado', producto: antesEditar });
    }, 800);
  };

  const cancelarEdicion = () => {
    setEditandoId(null);
    setProductoEditado({ nombre: '', precio: '', imagenes: [] });
  };

  const solicitarEliminar = (id) => {
    setModalEliminar({ abierto: true, id });
  };

  const confirmarEliminar = () => {
    const id = modalEliminar.id;
    const productoEliminar = productos.find((p) => p.id === id);
    setProductos(productos.filter((p) => p.id !== id));
    setModalEliminar({ abierto: false, id: null });
    setUndo({ accion: 'eliminado', producto: productoEliminar });
  };

  const cancelarEliminar = () => {
    setModalEliminar({ abierto: false, id: null });
  };

  const deshacer = () => {
    if (!undo) return;
    if (undo.accion === 'agregado') {
      setProductos(productos.filter(p => p.id !== undo.producto.id));
    } else if (undo.accion === 'eliminado') {
      setProductos([...productos, undo.producto]);
    } else if (undo.accion === 'editado') {
      setProductos(
        productos.map(p => p.id === undo.producto.id ? undo.producto : p)
      );
    }
    setUndo(null);
  };

  const manejarImagenes = (e, esEdicion = false) => {
    const archivos = Array.from(e.target.files);
    if (esEdicion) {
      setProductoEditado(prev => ({
        ...prev,
        imagenes: [...prev.imagenes, ...archivos]
      }));
    } else {
      setNuevoProducto(prev => ({
        ...prev,
        imagenes: [...prev.imagenes, ...archivos]
      }));
    }
  };

  const ModalConfirm = ({ mensaje, onConfirm, onCancel }) => (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white p-6 rounded shadow max-w-sm w-full text-center">
        <p className="mb-4 text-gray-800">{mensaje}</p>
        <button
          onClick={onConfirm}
          className="bg-red-600 text-white px-4 py-2 rounded mr-2 hover:bg-red-700 focus:outline-none"
        >
          Confirmar
        </button>
        <button
          onClick={onCancel}
          className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500 focus:outline-none"
        >
          Cancelar
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <Navbar />
      <div className="max-w-6xl mx-auto">

        <h1 className="text-4xl font-bold text-center text-gray-800 mb-10">
          Panel de Administrador
        </h1>

        {/* Buscador con botón limpiar */}
        <div className="mb-6 max-w-md mx-auto flex items-center">
          <input
            type="text"
            placeholder="Buscar productos..."
            value={busqueda}
            onChange={(e) => {
              setBusqueda(e.target.value);
              setPaginaActual(1);
            }}
            className="flex-grow border border-gray-400 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-gray-900"
            aria-label="Buscar productos"
          />
          {busqueda && (
            <button
              onClick={() => setBusqueda('')}
              aria-label="Limpiar búsqueda"
              title="Limpiar búsqueda"
              className="ml-2 text-gray-500 hover:text-gray-800 cursor-pointer transition rounded-full p-1 bg-gray-200 hover:bg-gray-300 focus:outline-none"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>

        {/* Agregar producto */}
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-gray-700">
            Agregar nuevo producto
          </h2>
          <form
            onSubmit={agregarProducto}
            className="flex flex-col md:flex-row md:items-center gap-4"
            aria-label="Formulario agregar producto"
          >
            <input
              type="text"
              placeholder="Nombre"
              value={nuevoProducto.nombre}
              onChange={(e) => setNuevoProducto({ ...nuevoProducto, nombre: e.target.value })}
              className="border border-gray-400 p-3 rounded w-full md:w-1/3 shadow-sm text-gray-900"
              aria-label="Nombre producto"
              required
            />
            <input
              type="number"
              placeholder="Precio"
              value={nuevoProducto.precio}
              onChange={(e) => setNuevoProducto({ ...nuevoProducto, precio: e.target.value })}
              className="border border-gray-400 p-3 rounded w-full md:w-1/6 shadow-sm text-gray-900"
              aria-label="Precio producto"
              required
              min="0"
              step="any"
            />
            <label
              htmlFor="input-imagenes"
              className="cursor-pointer bg-gray-300 hover:bg-gray-400 text-gray-900 px-4 py-2 rounded select-none"
              title="Seleccionar imágenes del producto"
            >
              Seleccionar imágenes
            </label>
            <input
              type="file"
              id="input-imagenes"
              multiple
              accept="image/*"
              onChange={manejarImagenes}
              className="hidden"
              aria-label="Seleccionar imágenes producto"
            />
            <button
              type="submit"
              disabled={loading}
              className="bg-green-600 text-white px-6 py-3 rounded hover:bg-green-700 transition font-semibold shadow disabled:opacity-50"
              aria-disabled={loading}
              aria-busy={loading}
            >
              {loading ? 'Guardando...' : 'Agregar'}
            </button>
          </form>
          {nuevoProducto.imagenes.length > 0 && (
            <div className="flex space-x-2 mt-3 overflow-x-auto">
              {nuevoProducto.imagenes.map((img, i) => (
                <img
                  key={i}
                  src={URL.createObjectURL(img)}
                  alt={`Imagen producto ${nuevoProducto.nombre}`}
                  className="h-16 rounded border object-contain"
                />
              ))}
            </div>
          )}
        </section>

        {/* Tabla productos */}
        <section>
          <h2 className="text-2xl font-semibold mb-4 text-gray-700">
            Lista de productos
          </h2>
          <div className="overflow-x-auto rounded shadow-md">
            <table className="min-w-full bg-white">
              <thead>
                <tr className="bg-gray-200 text-gray-700">
                  <th className="py-3 px-4 text-left">Nombre</th>
                  <th className="py-3 px-4 text-left">Precio</th>
                  <th className="py-3 px-4 text-left">Imágenes</th>
                  <th className="py-3 px-4 text-left">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {productosMostrados.length === 0 && (
                  <tr>
                    <td colSpan="4" className="text-center py-6 text-gray-500">
                      No se encontraron productos.
                    </td>
                  </tr>
                )}
                {productosMostrados.map((producto) => (
                  <tr
                    key={producto.id}
                    className="border-t border-gray-300"
                  >
                    <td className="py-3 px-4 text-gray-900">
                      {editandoId === producto.id ? (
                        <input
                          type="text"
                          value={productoEditado.nombre}
                          onChange={(e) =>
                            setProductoEditado({ ...productoEditado, nombre: e.target.value })
                          }
                          className="border p-2 rounded w-full text-gray-900"
                          aria-label={`Editar nombre de ${producto.nombre}`}
                        />
                      ) : (
                        producto.nombre
                      )}
                    </td>
                    <td className="py-3 px-4 text-gray-900">
                      {editandoId === producto.id ? (
                        <input
                          type="number"
                          value={productoEditado.precio}
                          onChange={(e) =>
                            setProductoEditado({ ...productoEditado, precio: e.target.value })
                          }
                          className="border p-2 rounded w-full text-gray-900"
                          aria-label={`Editar precio de ${producto.nombre}`}
                        />
                      ) : (
                        `$${producto.precio.toLocaleString('es-CL')}`
                      )}
                    </td>
                    <td className="py-3 px-4 text-gray-900">
                      {producto.imagenes.length > 0 ? (
                        <div className="flex space-x-2 overflow-x-auto max-w-xs">
                          {producto.imagenes.map((img, i) => {
                            if (typeof img === 'string') {
                              return (
                                <img
                                  key={i}
                                  src={img}
                                  alt={`Imagen producto ${producto.nombre}`}
                                  className="h-16 rounded border object-contain"
                                />
                              );
                            } else {
                              return (
                                <img
                                  key={i}
                                  src={URL.createObjectURL(img)}
                                  alt={`Imagen producto ${producto.nombre}`}
                                  className="h-16 rounded border object-contain"
                                />
                              );
                            }
                          })}
                        </div>
                      ) : (
                        <span className="text-gray-500">Sin imágenes</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {editandoId === producto.id ? (
                        <div className="flex gap-2">
                          <button
                            onClick={() => guardarEdicion(producto.id)}
                            disabled={loading}
                            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition disabled:opacity-50"
                            aria-disabled={loading}
                          >
                            Guardar
                          </button>
                          <button
                            onClick={cancelarEdicion}
                            className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition"
                          >
                            Cancelar
                          </button>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <button
                            onClick={() => iniciarEdicion(producto)}
                            className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition"
                          >
                            Editar
                          </button>
                          <button
                            onClick={() => solicitarEliminar(producto.id)}
                            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition"
                          >
                            Eliminar
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Paginación */}
          {totalPaginas > 1 && (
            <nav
              aria-label="Paginación productos"
              className="flex justify-center mt-6 space-x-2 select-none"
            >
              <button
                onClick={() => setPaginaActual((p) => Math.max(p - 1, 1))}
                disabled={paginaActual === 1}
                className="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400 disabled:opacity-50 focus:outline-none"
                aria-label="Página anterior"
              >
                ‹
              </button>
              {[...Array(totalPaginas).keys()].map((i) => (
                <button
                  key={i}
                  onClick={() => setPaginaActual(i + 1)}
                  aria-current={paginaActual === i + 1 ? 'page' : undefined}
                  className={`px-3 py-1 rounded focus:outline-none ${
                    paginaActual === i + 1
                      ? 'bg-yellow-400 font-semibold'
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
              <button
                onClick={() => setPaginaActual((p) => Math.min(p + 1, totalPaginas))}
                disabled={paginaActual === totalPaginas}
                className="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400 disabled:opacity-50 focus:outline-none"
                aria-label="Página siguiente"
              >
                ›
              </button>
            </nav>
          )}
        </section>

        {/* Modal Confirmar Eliminar */}
        {modalEliminar.abierto && (
          <ModalConfirm
            mensaje="¿Estás seguro que quieres eliminar este producto?"
            onConfirm={confirmarEliminar}
            onCancel={cancelarEliminar}
          />
        )}

        {/* Undo */}
        {undo && (
          <div
            role="alert"
            className="fixed bottom-4 right-4 bg-yellow-400 px-4 py-2 rounded shadow-lg flex items-center space-x-4 z-50"
          >
            <span className="text-gray-900 font-semibold">
              Acción realizada: {undo.accion}
            </span>
            <button
              onClick={deshacer}
              className="bg-gray-900 text-yellow-400 px-3 py-1 rounded hover:bg-gray-800 focus:outline-none"
              aria-label="Deshacer última acción"
            >
              Deshacer
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
