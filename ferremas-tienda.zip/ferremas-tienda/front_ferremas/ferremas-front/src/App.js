import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';

import Home from './pages/Home';
import Login from './pages/Login';
import Registro from './pages/Registro';
import Catalogo from './pages/Catalogo';
import Pago from './pages/Pago';
import Account from './pages/Account';
import AdminPanel from './pages/AdminPanel';
import BodegueroPanel from './pages/BodegueroPanel';
import VendedorPanel from './pages/VendedorPanel';
import ContadorPanel from './pages/ContadorPanel';

function RutasProtegidas({ children, perfilRequerido }) {
  const usuario = JSON.parse(localStorage.getItem('usuario'));
  const location = useLocation();

  if (!usuario) {
    // No logueado: redirigir a login
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (perfilRequerido && usuario.perfil !== perfilRequerido) {
    // Usuario no tiene el rol necesario: redirigir a home
    return <Navigate to="/" replace />;
  }

  // Usuario autenticado y con permiso (si se requiere)
  return children;
}

function App() {
  return (
    <Router>
      <Routes>
        {/* Rutas públicas */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/registro" element={<Registro />} />

        {/* Rutas protegidas para usuarios logueados */}
        <Route
          path="/catalogo"
          element={
            <RutasProtegidas>
              <Catalogo />
            </RutasProtegidas>
          }
        />
        <Route
          path="/pago"
          element={
            <RutasProtegidas>
              <Pago />
            </RutasProtegidas>
          }
        />
        <Route
          path="/mi-cuenta"
          element={
            <RutasProtegidas>
              <Account />
            </RutasProtegidas>
          }
        />

        {/* Ruta Admin - solo usuarios con perfil "administrador" */}
        <Route
          path="/admin"
          element={
            <RutasProtegidas perfilRequerido="administrador">
              <AdminPanel />
            </RutasProtegidas>
          }
        />

        {/* Ruta Bodeguero - solo usuarios con perfil "bodeguero" */}
        <Route
          path="/bodeguero"
          element={
            <RutasProtegidas perfilRequerido="bodeguero">
              <BodegueroPanel />
            </RutasProtegidas>
          }
        />

        {/* Ruta Vendedor - solo usuarios con perfil "vendedor" */}
        <Route
          path="/vendedor"
          element={
            <RutasProtegidas perfilRequerido="vendedor">
              <VendedorPanel />
            </RutasProtegidas>
          }
        />

        {/* Ruta Contador - solo usuarios con perfil "contador" */}
        <Route
          path="/contador"
          element={
            <RutasProtegidas perfilRequerido="contador">
              <ContadorPanel />
            </RutasProtegidas>
          }
        />

        {/* Ruta fallback: redirigir a Home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
